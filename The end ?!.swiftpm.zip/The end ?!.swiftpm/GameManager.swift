import SwiftUI

class GameManager: ObservableObject {
    @Published var selectedScene = Scenes.scene1
    @Published var constante : Double = 0.0
    @Published var tempo : Double = 0.0
    
    lazy var scene6: Sexta = {
        let scene = Sexta(size: CGSize(width: screenSize.width, height: screenSize.height))
        scene.scaleMode = .aspectFill
        scene.backgroundColor = preto
        scene.gameManager = self
        return scene
    }()
    lazy var scene8: Oitava = {
        let scene = Oitava(size: CGSize(width: screenSize.width, height: screenSize.height))
        scene.scaleMode = .aspectFill
        scene.backgroundColor = preto
        scene.gameManager = self
        return scene
    }()
    
    lazy var scene9: Nona = {
        let scene = Nona(size: CGSize(width: screenSize.width, height: screenSize.height))
        scene.scaleMode = .aspectFill
        scene.backgroundColor = preto
        scene.gameManager = self
        return scene
    }()
    
    lazy var scene10: Decima = {
        let scene = Decima(size: CGSize(width: screenSize.width, height: screenSize.height))
        scene.scaleMode = .aspectFill
        scene.backgroundColor = preto
        scene.gameManager = self
        return scene
    }()
    
    func goToScene(_ scene: Scenes) {
        selectedScene = scene
    }
    
    func reset(valor: CGFloat = 0.0){
        constante = valor
        tempo = valor
    }
    
}
