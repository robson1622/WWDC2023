import SpriteKit
import SwiftUI

//let screenSize = UIScreen.main.bounds.size
//let preto = UIColor(red: 20/255, green: 20/255, blue: 20/255, alpha: 1.0)
//let roxo = UIColor(red: 144/255, green: 31/255, blue: 184/255, alpha: 1.0)

class Sexta: Assets {
    weak var gameManager: GameManager?
    var sprite : SKSpriteNode!
    var pudin : SKSpriteNode!
    var tam : SKLabelNode!

    
    
    override func didMove(to view: SKView) {
        // Aqui vai a parte de design
        //Background
        desenharBG()
        
        let image =  SKSpriteNode(imageNamed: "sexta")
        image.anchorPoint = CGPoint(x: 0, y: 1 )
        image.size = CGSize(width: dw * 35, height: dw * 17.7)
        image.position = CGPoint(x: dw * 15, y: dh * 80)
        addChild(image)
        
        let balao = desenharBalao04()
        addChild(balao)
    
        
        //Hubble
        let hub = desenharHubble()
        addChild(hub)
        //pudin
        pudin = desenharPudin()
        addChild(pudin)
        
        sprite = desenharFogueteContinue()
        addChild(sprite)
        
        tam = SKLabelNode(text: "1.0x")
        tam.numberOfLines = 0
        tam.fontName = font
        tam.fontSize = 20
        tam.fontColor = .black
        tam.position = CGPoint(x: dw * 77, y: dh * 58)
        addChild(tam)
         
    }
    func updatePudin(constante:Double){
        pudin.setScale(1 + (constante/100))
        tam.position = CGPoint(x: (dw * 77) + constante, y: dh * 58 )
        tam.text = "\(round(((1 + (constante/100)) * 100))/100)" + "x"
    }
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
            guard let touch = touches.first else { return }
            let location = touch.location(in: self)

            if sprite.contains(location) {
                for child in self.children {
                    child.removeFromParent()
                }
                gameManager?.reset()
                gameManager?.goToScene(.scene5)
                playMusic(sound: "go", volume: 0.3)
            }
        }
    
}

