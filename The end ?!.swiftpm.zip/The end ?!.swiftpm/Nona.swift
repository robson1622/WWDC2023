

import SpriteKit
import SwiftUI

class Nona: Assets{
    weak var gameManager: GameManager?
    var sprite : SKSpriteNode!
    var g1 : SKSpriteNode!
    var g2 : SKSpriteNode!
    var tam : SKLabelNode!
    
    override func didMove(to view: SKView) {
        // Aqui vai a parte de design
        //Background
        desenharBG()
        
        let image =  SKSpriteNode(imageNamed: "nona")
        image.anchorPoint = CGPoint(x: 0, y: 1 )
        image.size = CGSize(width: dw * 35, height: dw * 27.5)
        image.position = CGPoint(x: dw * 15, y: dh * 80)
        addChild(image)
        
        let caixa = desenharBalao04()
        caixa.color = .black
        caixa.blendMode = .subtract
        addChild(caixa)
        
        
        
        g1 = desenharGalaxia1()
        g1.position = CGPoint(x: dw * 66, y: dh * 60)
        g1.setScale(0.0)
        g1.size = CGSize(width: dw * 10, height: dw * 10)
        addChild(g1)
        g2 = desenharGalaxia2()
        g2.position = CGPoint(x: dw * 66, y: dh * 40)
        g2.setScale(0.0)
        g2.size = CGSize(width: dw * 10, height: dw * 10)
        addChild(g2)
        
        let barra = SKSpriteNode(imageNamed: "ret")
        barra.anchorPoint = CGPoint(x: 0.5 , y:0.5)
        barra.position = CGPoint(x: dw * 75 , y: dh * 50)
        barra.size = CGSize(width: 5, height: dw * 16)
        addChild(barra)
        
        
        let valor = 99999999
        tam = SKLabelNode(text: String(format: "%08d", valor))
        tam.numberOfLines = 0
        tam.preferredMaxLayoutWidth = 350
        tam.fontName = font
        tam.fontSize = 20
        tam.fontColor = .white
        tam.position = CGPoint(x: dw * 82, y: dh * 53)
        addChild(tam)
        
        sprite =  desenharFogueteContinue()
        addChild(sprite)
        
        let hub = desenharHubble()
        addChild(hub)
        
        
    }
    func updatePudin(constante:Double){
        g1.setScale((constante/100))
        g2.setScale((constante/100))
        var valor = constante * 100000
        if(valor == 0){
            valor = 9999999
        }
        else {
            valor = 9999999 - valor + 2
        }
        tam.text = "\(round(valor))" + " ly"
    }
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
            guard let touch = touches.first else { return }
            let location = touch.location(in: self)

            if sprite.contains(location) {
                for child in self.children {
                    child.removeFromParent()
                }
                gameManager?.reset()
                gameManager?.goToScene(.scene7)
                playMusic(sound: "go", volume: 0.3)
            }
        }
    
}

