//
//  DecimaPrimeira.swift
//  The end again?
//
//  Created by Robson Borges on 17/04/23.
//
import SpriteKit
import SwiftUI


class DecimaPrimeira : Assets{
    weak var gameManager: GameManager?
    var sprite : SKSpriteNode!
    @State var rotacao : CGFloat = 0
    @State var movimento : CGFloat = 0
    
    override func didMove(to view: SKView) {
        //Background
        desenharBG()
        
        // Criando o nó do texto preto
        let titulo = SKLabelNode(text: "The end ?!")
        titulo.numberOfLines = 3
        titulo.horizontalAlignmentMode = .left
        titulo.fontName = font
        titulo.fontSize = 40
        titulo.fontColor = .white
        titulo.position = CGPoint(x: dw * 10, y: dh * 50)
        addChild(titulo)
        let fim = SKLabelNode(text: "And if the end was a new beginning,\nwhat would your new cake taste like? \n Thanks for playing.")
        fim.numberOfLines = 3
        fim.horizontalAlignmentMode = .left
        fim.fontName = font
        fim.fontSize = 26
        fim.fontColor = roxo
        fim.position = CGPoint(x: dw * 10, y: dh * 30)
        addChild(fim)
        //683 × 761
        let pudin = SKSpriteNode(imageNamed: "planetaFim")
        pudin.anchorPoint = CGPoint(x: 1, y: 0)
        pudin.position = CGPoint(x: dw * 100, y: 0)
        pudin.size = CGSize(width: dw * 50, height: dw * 56)
        addChild(pudin)
            
    }
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
            for child in self.children {
                child.removeFromParent()
            }
            gameManager?.goToScene(.scene1)
        }
    
}

