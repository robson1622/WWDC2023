
import SwiftUI

struct SlideView: View {
    @Binding var valor : Double
    
    var body: some View {
        VStack {
            Slider(value: $valor, in: 0...100)
                .padding()
                .foregroundColor(Color.purple)
        }
    }
    
}
