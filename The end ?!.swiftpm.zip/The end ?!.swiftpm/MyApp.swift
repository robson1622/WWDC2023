
import SpriteKit
import SwiftUI
import AVFoundation


public var screenSize = UIScreen.main.bounds.size
public let preto = UIColor(red: 20/255, green: 20/255, blue: 20/255, alpha: 1.0)
public let roxo = UIColor(red: 144/255, green: 31/255, blue: 184/255, alpha: 1.0)

public var seletor = 0
public var font = "Georgia"

public let dw = screenSize.width/100
public let dh = screenSize.height/100
public let width = screenSize.width
public let height = screenSize.height

public var isHorizontal : Bool = UIScreen.main.bounds.size.width > UIScreen.main.bounds.size.height

final class Constantes: ObservableObject {
    @Published var tempo: CGFloat = 0
    @Published var constante: CGFloat = 0
}

struct GerenciadorViews: View {
    @StateObject var gameManager = GameManager()
    @StateObject var constantes = Constantes()
    @State var isPlaying = false
    @State var isImageVisible1  = true
    @State var isImageVisible2  = false
    
    var player: AVAudioPlayer?
    
        var body: some View {
            
            VStack {
                    switch gameManager.selectedScene {
                    case .scene1:
                        if screenSize.width < screenSize.height{
                            SpriteView(scene: erroTela())
                        }
                        else{
                            SpriteView(scene: getScene1())
                                .onAppear(){
                                    playBack(sound: "audio",volume: 0.3)
                                }
                        }
                    case .scene2:
                        SpriteView(scene: getScene2())
                    case .scene3:
                        SpriteView(scene: getScene5())
                    case .scene4:
                        ZStack{
                            SpriteView(scene: gameManager.scene6)
                            SlideView(valor: $gameManager.constante)
                                .position(CGPoint(x: dw * 38, y: dh * 26))
                                .frame(width: dw * 32)
                                .onChange(of: gameManager.constante) { newValue in
                                    gameManager.scene6.updatePudin(constante: newValue)
                                }
                        }
                    case .scene5:
                        ZStack{
                            SpriteView(scene: gameManager.scene8)
                            SlideView(valor: $gameManager.constante)
                                .position(CGPoint(x: dw * 38, y: dh * 26))
                                .frame(width: dw * 32)
                                .onChange(of: gameManager.constante) { newValue in
                                    gameManager.scene8.updatePudin(constante: newValue)
                                }
                        }
                    case .scene6:
                        ZStack{
                            SpriteView(scene: gameManager.scene9)
                            SlideView(valor: $gameManager.constante)
                                .position(CGPoint(x: dw * 38, y: dh * 26))
                                .frame(width: dw * 32)
                                .onChange(of: gameManager.constante) { newValue in
                                    gameManager.scene9.updatePudin(constante: newValue)
                                }
                            
                        }
                    case .scene8:
                        SpriteView(scene: getScene11())
                    case .scene7:
                        ZStack{
                            
                            SpriteView(scene: gameManager.scene10)
                            SlideView(valor: $gameManager.constante)
                                .position(CGPoint(x: dw * 30, y: dh * 11))
                                .frame(width: dw * 40)
                                .onChange(of: gameManager.constante) { newValue in
                                    gameManager.scene10.updateConstante(constante: newValue)
                                }
                            
                            VStack {
                                Button(action: {
                                    self.isPlaying.toggle()
                                }, label: {
                                    Image(systemName: isPlaying ? "pause.circle.fill" : "play.circle.fill")
                                        .font(.system(size: dw * 3))
                                        .foregroundColor(Color(red: 10, green: 10, blue: 10))
                                })
                            }
                            .position(CGPoint(x: dw * 82, y: dh * 11))
                            .onReceive(Timer.publish(every: 1/60, on: .main, in: .common).autoconnect(), perform: { _ in
                                if self.isPlaying {
                                    gameManager.scene10.atualizar()
                                }
                            })
                            VStack{
                                if isImageVisible1 {
                                    Image("exp1")
                                        .resizable()
                                        .position(x: dw * 23 , y: -dh * 12)
                                        .frame(width: dw * 30 , height: dw * 15)
                                        .onTapGesture {
                                            isImageVisible1 = false
                                            isImageVisible2 = true
                                        }
                                }
                                if isImageVisible2 {
                                    Image("exp2")
                                        .resizable()
                                        .position(x: dw * 27 ,y: -dh * 8)
                                        .frame(width: dw * 30 , height: dw * 17)
                                        .onTapGesture {
                                            isImageVisible2 = false
                                        }
                                }
                            }
                            VStack {
                                Button(action: {
                                    gameManager.scene10.reset()
                                }, label: {
                                    Image(systemName: "arrow.clockwise")
                                        .font(.system(size: dw * 3))
                                        .foregroundColor(Color(red: 10, green: 10, blue: 10))
                                })
                            }
                            .position(CGPoint(x: dw * 87 , y: dh * 11))
                             
                            
                        }
                        
                    }
                
            }
        }

        // Funções que criam as cenas.
        // Todas devem configurar o gameManager para poder controlar a passagem de telas

        func getScene1() -> SKScene {
            let scene = Primeira(size: CGSize(width: screenSize.width, height: screenSize.height))
            scene.scaleMode = .aspectFill
            scene.backgroundColor = preto
            scene.gameManager = gameManager
            return scene
        }

        func getScene2() -> SKScene {
            let scene = Segunda(size: CGSize(width: screenSize.width, height: screenSize.height))
            scene.scaleMode = .aspectFill
            scene.backgroundColor = preto
            scene.gameManager = gameManager
            return scene
        }
        func getScene5() -> SKScene {
            let scene = Quinta(size: CGSize(width: screenSize.width, height: screenSize.height))
            scene.scaleMode = .aspectFill
            scene.backgroundColor = preto
            scene.gameManager = gameManager
            return scene
        }
        func getScene8() -> SKScene {
            let scene = Oitava(size: CGSize(width: screenSize.width, height: screenSize.height))
            scene.scaleMode = .aspectFill
            scene.backgroundColor = preto
            scene.gameManager = gameManager
            return scene
        }
        func getScene9() -> SKScene {
            let scene = Nona(size: CGSize(width: screenSize.width, height: screenSize.height))
            scene.scaleMode = .aspectFill
            scene.backgroundColor = preto
            scene.gameManager = gameManager
            return scene
        }
        func getScene10() -> SKScene {
            let scene = Decima(size: CGSize(width: screenSize.width, height: screenSize.height))
            scene.scaleMode = .aspectFill
            scene.backgroundColor = preto
            scene.gameManager = gameManager
            return scene
        }
        func getScene11() -> SKScene {
            let scene = DecimaPrimeira(size: CGSize(width: screenSize.width, height: screenSize.height))
            scene.scaleMode = .aspectFill
            scene.backgroundColor = preto
            scene.gameManager = gameManager
            return scene
        }
        func erroTela() -> SKScene {
            let scene = ErroTela(size: CGSize(width: screenSize.width, height: screenSize.height))
            scene.scaleMode = .aspectFill
            scene.backgroundColor = preto
            scene.gameManager = gameManager
            return scene
        }
    
}

@main
struct MyApp: App {
    var backgroundMusic: AVAudioPlayer!
    var body: some Scene {
        
        WindowGroup {
            GeometryReader { geo in
                GerenciadorViews()
                    .onChange(of: geo.size) { newValue in
                        screenSize = geo.size
                        if geo.size.width < geo.size.height{
                            isHorizontal = false
                            
                        }
                        else{
                            isHorizontal = true
                        }
                        
                    }
                
            }
            .ignoresSafeArea()
        }
        
        
    }
}


