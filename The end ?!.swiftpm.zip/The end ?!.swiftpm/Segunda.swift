import SpriteKit
import SwiftUI

//let screenSize = UIScreen.main.bounds.size
//let preto = UIColor(red: 20/255, green: 20/255, blue: 20/255, alpha: 1.0)
//let roxo = UIColor(red: 144/255, green: 31/255, blue: 184/255, alpha: 1.0)

class Segunda: Assets {
    weak var gameManager: GameManager?
    var sprite : SKSpriteNode!
    
    
    override func didMove(to view: SKView) {
        // Aqui vai a parte de design
        //Background
        desenharBG()
        let image =  SKSpriteNode(imageNamed: "segunda")
        image.anchorPoint = CGPoint(x: 0, y: 1 )
        image.size = CGSize(width: dw * 50, height: dw * 20)
        image.position = CGPoint(x: dw * 15, y: dh * 80)
        addChild(image)
        
        let hub = desenharHubble()
        addChild(hub)
        
        // Criando a sprite
        sprite = desenharFogueteContinue(posicao: false)
        addChild(sprite)
        
       
        
        
         
    }
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
            guard let touch = touches.first else { return }
            let location = touch.location(in: self)

            if sprite.contains(location) {
                for child in self.children {
                    child.removeFromParent()
                }
                gameManager?.goToScene(.scene3)
                playMusic(sound: "go", volume: 0.3)
            }
        }
    
}

