//
//  Assets.swift
//  The end again?
//
//  Created by Robson Borges on 14/04/23.
//
import SpriteKit
import AVFoundation
let box = 10

var audioPlayer: AVAudioPlayer?

func playMusic(sound: String , volume: Float){
    if let path = Bundle.main.path(forResource: sound, ofType: "mp3"){
        do {
            audioPlayer = try AVAudioPlayer(contentsOf: URL(fileURLWithPath:path))
            audioPlayer?.volume = volume
            audioPlayer?.play()
        } catch {
            print("ERRO ao tentar tocar a musica")
        }
    }
        
}
var back : AVAudioPlayer?
func playBack(sound: String , volume: Float){
    if let path = Bundle.main.path(forResource: sound, ofType: "mp3"){
        do {
            back = try AVAudioPlayer(contentsOf: URL(fileURLWithPath:path))
            back?.volume = volume
            back?.play()
        } catch {
            print("ERRO ao tentar tocar a musica")
        }
    }
        
}

class Assets: SKScene{
    
    
    func desenharFogueteContinue(posicao:Bool = true) -> SKSpriteNode{
        // Criando a sprite
        let sprite = SKSpriteNode(imageNamed: "continue1")
        
        sprite.size = CGSize(width: dw * 25, height: dw * 10)
        // Criando a animação
        let animFrames = ["continue1", "continue2", "continue3", "continue4"].map { SKTexture(imageNamed: $0) }
        let animation = SKAction.animate(with: animFrames, timePerFrame: 0.1)
        if(posicao){
            sprite.position = CGPoint(x: -dw * 25, y: dh * 15)
            sprite.run(SKAction.move(to: CGPoint(x: dw * 81, y: dh * 15 ), duration: 10))
        }
        else{
            sprite.position = CGPoint(x: -dw * 25, y: dh * 40)
            sprite.run(SKAction.move(to: CGPoint(x: dw * 21.5, y: dh * 40), duration: 5))
        }
        sprite.run(SKAction.repeatForever(animation))
        return sprite
    }
    func desenharFogueteStart() -> SKSpriteNode{
        // Criando a sprite
        let sprite = SKSpriteNode(imageNamed: "start1")
        sprite.position = CGPoint(x: dw * 47, y: dh * 40)
        sprite.size = CGSize(width: dw * 25, height: dw * 10)
        // Criando a animação
        let animFrames = ["start1", "start2", "start3", "start4"].map { SKTexture(imageNamed: $0) }
        let animation = SKAction.animate(with: animFrames, timePerFrame: 0.1)
        sprite.run(SKAction.repeatForever(animation))
        return sprite
    }
    func desenharBalao02(texto: String,shift: CGFloat = 0){
        let posicao = CGPoint(x: dw * 30 , y: dh * 78)
        let texto3 = SKLabelNode(text: texto)
        texto3.verticalAlignmentMode = SKLabelVerticalAlignmentMode.top
        texto3.numberOfLines = 0
        texto3.preferredMaxLayoutWidth = dw * 28
        texto3.fontName = font
        texto3.fontSize = 25
        texto3.fontColor = .black
        texto3.position = posicao
        
        let balao3 = SKSpriteNode(imageNamed: "Balao0")
        balao3.anchorPoint = CGPoint(x:0,y:1)
        balao3.position = CGPoint(x: posicao.x - (dw * 15), y: posicao.y + dh)
        balao3.size = CGSize(width: dw * 30, height: dh * 30)
        
        addChild(balao3)
        addChild(texto3)
    }
    func desenharBalao04() -> SKSpriteNode{
        let caixa = SKSpriteNode(imageNamed: "Balao2")
        caixa.anchorPoint = CGPoint(x:0,y:1)
        caixa.position = CGPoint(x: dw * 55 , y: dh * 80)
        caixa.size = CGSize(width: dw * 35, height: dh * 55)
        return caixa
    }
    func desenharPudin(tamanho :CGFloat = 1) -> SKSpriteNode{
        //pudin
        let pudin = SKSpriteNode(imageNamed: "pudin")
        pudin.anchorPoint = CGPoint(x: 0.5, y: 1)
        pudin.position = CGPoint(x: dw * 72.5, y: dh * 62)
        pudin.setScale(tamanho)
        pudin.size = CGSize(width: dw * 12, height: dw * 12)
        return pudin
    }
    func desenharHubble() -> SKSpriteNode{
        let hub = SKSpriteNode(imageNamed: "Hubble")
        hub.anchorPoint = CGPoint(x:0,y:1)
        hub.position = CGPoint(x: dw * 5 , y: dh * 85)
        hub.size = CGSize(width: dw * 10, height: dw * 10)
        return hub
    }
    func desenharBG(){
        self.backgroundColor = preto
        let forma1 = SKSpriteNode(imageNamed: "forma1")
        let forma2 = SKSpriteNode(imageNamed: "forma2")
        
        //1345 × 2848
        forma1.anchorPoint = CGPoint(x:0,y:0)
        forma1.position = CGPoint(x:0, y:0)
        forma1.size = CGSize(width: dw * 20, height: dw * 50)
        addChild(forma1)
        
        //915 × 1925
        forma2.anchorPoint = CGPoint(x:1,y:1)
        forma2.position = CGPoint(x: dw * 100, y: dh * 100)
        forma2.size = CGSize(width: dw * 30, height: dh * 63)
        addChild(forma2)
    }
    func botao(posicao:Int,nameImage: String,tamanho:CGSize,teta:CGFloat){
        let button = SKSpriteNode(imageNamed: nameImage)
        button.anchorPoint = CGPoint(x:0.5,y:0.5)
        button.zRotation = teta
        button.position = CGPoint(x: screenSize.width/2 + 1494/3 + 60, y: screenSize.height/2 + 20)
        button.size = tamanho
        addChild(button)
    }
    func desenharGalaxia1() -> SKSpriteNode{
        let galaxia1 = SKSpriteNode(imageNamed: "Galaxia1")
        galaxia1.anchorPoint = CGPoint(x: 0.5,y:0.5)
        galaxia1.position = CGPoint(x: dw * 15, y: dh * 15)
        galaxia1.size = CGSize(width: dw * 15, height: dw * 15)
        galaxia1.run(SKAction.repeatForever(SKAction.rotate(byAngle: -0.5, duration: 10.0)))
        return galaxia1
    }
    func desenharGalaxia2() -> SKSpriteNode{
        //1023 × 642
        let galaxia2 = SKSpriteNode(imageNamed: "Galaxia2")
        
        galaxia2.anchorPoint = CGPoint(x: 0.5,y:0.5)
        galaxia2.position = CGPoint(x: dw * 15 , y: dh * 76)
        galaxia2.size = CGSize(width: dw * 15, height: dw * 20)
        //galaxia2.run(SKAction.repeatForever(SKAction.rotate(byAngle: -1.0, duration: 10.0)))
        return galaxia2
    }
    func desenharBuraco() -> SKSpriteNode{
        //1360 × 550
        let Buraco = SKSpriteNode(imageNamed: "Buraco")
        Buraco.anchorPoint = scene!.anchorPoint
        Buraco.position = CGPoint(x: dw * 80, y: dh * 15 )
        Buraco.size = CGSize(width: dw * 20, height: dw * 15)
        return Buraco
    }
    func desenharConstante() -> SKSpriteNode{
        //1360 × 550
        let Buraco = SKSpriteNode(imageNamed: "cc")
        Buraco.anchorPoint = scene!.anchorPoint
        Buraco.position = CGPoint(x: dw * 35, y: dh * 87)
        Buraco.size = CGSize(width: dw * 3, height: dw * 3)
        return Buraco
    }
    func desenharAstro(nome: String) -> SKSpriteNode{
        let galaxia1 = SKSpriteNode(imageNamed: nome)
        galaxia1.anchorPoint = CGPoint(x: 0.5,y:0.5)
        galaxia1.position = CGPoint(x: dw * 15, y: dh * 15)
        galaxia1.size = CGSize(width: dw * 5.3, height: dw * 5.3)
        galaxia1.run(SKAction.repeatForever(SKAction.rotate(byAngle: -0.5, duration: 10.0)))
        return galaxia1
    }
    
}

