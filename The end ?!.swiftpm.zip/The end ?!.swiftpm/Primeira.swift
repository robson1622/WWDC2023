import SpriteKit
import SwiftUI


class Primeira: Assets {
    weak var gameManager: GameManager?
    var sprite : SKSpriteNode!
    @State var rotacao : CGFloat = 0
    @State var movimento : CGFloat = 0
    
    override func didMove(to view: SKView) {
        //Background
        desenharBG()
        let g1 = desenharGalaxia1()
        let g2 = desenharBuraco()
        let b1 = desenharGalaxia2()
        sprite = desenharFogueteStart()
        addChild(sprite)
        addChild(g1)
        addChild(g2)
        addChild(b1)
        
        
        
        // Criando o nó do texto preto
        let titulo = SKLabelNode(text: "The end?!")
        titulo.fontName = font
        titulo.fontSize = 60
        titulo.fontColor = .white
        titulo.position = CGPoint(x: screenSize.width/2, y: screenSize.height/2 + 100)
        addChild(titulo)
        
        // Criando o nó do texto preto
        let textNode = SKLabelNode(text: "What if the end was \n a new beginning?")
        textNode.numberOfLines = 2
        textNode.fontName = font
        textNode.fontSize = 25
        textNode.fontColor = .purple
        textNode.position = CGPoint(x: screenSize.width/2, y: screenSize.height/2 )
        addChild(textNode)
            
    }
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
            guard let touch = touches.first else { return }
            let location = touch.location(in: self)

            if sprite.contains(location) {
                for child in self.children {
                    child.removeFromParent()
                }
                gameManager?.goToScene(.scene2)
                playMusic(sound: "go", volume: 0.3)
            }
        }
    
}

