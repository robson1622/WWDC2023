


import SpriteKit
import SwiftUI
/*
 Esta parte é a final onde acontece a parte física de interação das galáxias
 */

class Astro : Assets{
    var massa : CGFloat = 1.0
    var objeto : SKSpriteNode!
    var velocidade : CGVector!
    var aceleracao : CGVector!
    
}


class Decima: Assets{
    weak var gameManager: GameManager?
    var sprite : SKSpriteNode!
    var tempo : CGFloat!
    var constante : CGFloat = 0.0
    
    
    var astros : [Astro] = [Astro]()
    var menu : SKSpriteNode!
    var a1 : Astro!
    var a2 : Astro!
    var a3 : Astro!
    var a4 : Astro!
    
    
    @State var pressed : Bool = false
  
    override func didMove(to view: SKView) {
        for child in self.children {
            child.removeFromParent()
        }
        reset()
        
        // Aqui vai a parte de design
        // Criando um sprite node retangular branco de tamanho 50x50
        
        
        
        
        
    }
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
            guard let touch = touches.first else { return }
            let location = touch.location(in: self)

            if sprite.contains(location) {
                for child in self.children {
                    child.removeFromParent()
                }
                gameManager?.reset()
                gameManager?.goToScene(.scene8)
                playMusic(sound: "go", volume: 0.3)
            }
        }
    func updateConstante(constante:Double){
        self.constante = constante
    }
    func updateTempo(tempo:Double){
        self.tempo = tempo
        atualizar()
    }
    
    func reset(){
        for child in self.children {
            child.removeFromParent()
        }
        astros.removeAll()
        desenharBG()
        
        
        let caixa = SKSpriteNode(imageNamed: "Balao2")
        caixa.anchorPoint = CGPoint(x:0.5,y:0.5)
        caixa.position = CGPoint(x: dw * 100, y: dh * 50 )
        caixa.size = CGSize(width: dw * 9, height: dw * 9)
        addChild(caixa)
        
        sprite = SKSpriteNode(imageNamed: "left1")
        sprite.anchorPoint = CGPoint(x:0.5,y:0.5)
        sprite.position = CGPoint(x: dw * 98 , y: dh * 50)
        sprite.size = CGSize(width: dw * 3, height: dw * 5)
        addChild(sprite)
        //Background
        
        let cc = desenharConstante()
        let balao = desenharHubble()
        balao.setScale(0.7)
        balao.position = CGPoint(x: dw * 5 , y: dh * 95)
        addChild(cc)
        addChild(balao)
        
        let image =  SKSpriteNode(imageNamed: "decima")
        image.anchorPoint = CGPoint(x: 0, y: 1 )
        image.size = CGSize(width: dw * 21, height: dw * 9)
        image.position = CGPoint(x: dw * 12, y: dh * 91)
        addChild(image)
        
        a1 = Astro()
        a2 = Astro()
        a3 = Astro()
        a4 = Astro()
        let proporcao = 1.2
        menu = SKSpriteNode(imageNamed: "menu")
        menu.anchorPoint = CGPoint(x: 0.5, y: 0.5)
        menu.position = CGPoint(x: dw * 50, y: dh * 10)
        menu.size = CGSize(width: dw * 30 * proporcao ,height: dw * 7 * proporcao)
        addChild(menu)
        
        a1.massa = 1 * proporcao
        a1.objeto = novo(pos: CGPoint(x: dw * 36.5 , y: dh * 10), id: 1)
        a1.velocidade = CGVector(dx: 0, dy: 0)
        addChild(a1.objeto)
        
        a2.massa = 10 * proporcao
        a2.objeto = novo(pos: CGPoint(x: dw * 45.5 , y: dh * 10), id: 3)
        a2.velocidade = CGVector(dx: 0, dy: 0)
        addChild(a2.objeto)
        
        a3.massa = 100 * proporcao
        a3.objeto = novo(pos: CGPoint(x: dw * 54.5 , y: dh * 10), id: 4)
        a3.velocidade = CGVector(dx: 0, dy: 0)
        addChild(a3.objeto)
        
        a4.massa = 1000 * proporcao
        a4.objeto = novo(pos: CGPoint(x: dw * 63.5 , y: dh * 10), id: 2)
        a4.velocidade = CGVector(dx:0, dy: 0)
        addChild(a4.objeto)
        
        astros.append(a1)
        astros.append(a2)
        astros.append(a3)
        astros.append(a4)
    }
    override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
        for touch in touches {
            let location = touch.location(in: self)
            if( a1.objeto.contains(location) || pressed){
                pressed = true
                let location = touch.location(in:self)
                
                a1.objeto.position = CGPoint(x: location.x, y: location.y)
            }
            else if( a2.objeto.contains(location) || pressed){
                pressed = true
                let location = touch.location(in:self)
                
                a2.objeto.position = CGPoint(x: location.x, y: location.y)
            }
            else if( a3.objeto.contains(location) || pressed){
                pressed = true
                let location = touch.location(in:self)
                
                a3.objeto.position = CGPoint(x: location.x, y: location.y)
            }
            else if( a4.objeto.contains(location) || pressed){
                pressed = true
                let location = touch.location(in:self)
                
                a4.objeto.position = CGPoint(x: location.x, y: location.y)
            }
            
        }
    }
    override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        for touch in touches {
            if a1.objeto.contains(touch.location(in: self)) {
                pressed = false
            }
        }
    }
    func novo(pos:CGPoint,id:Int) -> SKSpriteNode{
        var novoElemento = SKSpriteNode()
        novoElemento.position = pos
        
        if(id == 1){
            novoElemento = desenharGalaxia1()
            novoElemento.size = CGSize(width: dw * 5.3, height: dw * 5.3)
            novoElemento.position = pos
        }
        else if(id == 2){
            novoElemento = desenharAstro(nome:"buraco2")
            novoElemento.position = pos
        }
        else if(id == 3){
            novoElemento = desenharAstro(nome:"super1")
            novoElemento.position = pos
        }
        else{
            novoElemento = desenharAstro(nome:"super2")
            novoElemento.position = pos
        }
        return novoElemento
    }
    
    func atualizar() {
        
        let fator = constante/30
        let G = 1.0 // constante gravitacional
            for astro1 in astros {
                var acceleration = CGVector.zero
                for astro2 in astros {
                    if astro1 != astro2 {
                        let distance = hypot(astro1.objeto.position.x - astro2.objeto.position.x, astro1.objeto.position.y - astro2.objeto.position.y)
                        if(distance > 60){
                            let force = ( G * astro1.massa * astro2.massa ) / pow(distance,2)
                            let tensor : CGFloat = log(1 + distance)/100
                            let angle = atan2(astro2.objeto.position.y - astro1.objeto.position.y, astro2.objeto.position.x - astro1.objeto.position.x)
                            let forceVector = CGVector(dx: force * cos(angle), dy: force * sin(angle))
                            
                            acceleration.dx = ((forceVector.dx) - (tensor * fator * cos(angle))) / astro1.massa
                            acceleration.dy = ((forceVector.dy) - (tensor * fator * sin(angle))) / astro1.massa
                        }
                    }
                }
                if(astro1.objeto.position.x > screenSize.width || astro1.objeto.position.x < 0){
                    astro1.objeto.position.x += -astro1.velocidade.dx
                    astro1.velocidade.dx = -astro1.velocidade.dx * 0.8
                }
                if(astro1.objeto.position.y > screenSize.height || astro1.objeto.position.y < 0){
                    astro1.objeto.position.y += -astro1.velocidade.dy
                    astro1.velocidade.dy = -astro1.velocidade.dy * 0.8
                }
                astro1.aceleracao = acceleration
            }
            for body in astros {
                body.velocidade.dx = body.velocidade.dx + body.aceleracao.dx
                body.velocidade.dy = body.velocidade.dy + body.aceleracao.dy
                body.objeto.position = CGPoint(x: body.velocidade.dx + body.objeto.position.x, y:body.velocidade.dy + body.objeto.position.y)
            }
         
        }
    
    
    
}

