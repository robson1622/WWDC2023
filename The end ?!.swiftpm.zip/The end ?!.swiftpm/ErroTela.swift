import SpriteKit
import SwiftUI


class ErroTela: Assets {
    weak var gameManager: GameManager?
    var sprite : SKSpriteNode!
    
    override func didMove(to view: SKView) {
        //Background
        desenharBG()
        
        sprite = SKSpriteNode(imageNamed: "portrate")
        sprite.position = CGPoint(x: dw * 50, y: dh * 50)
        sprite.size = CGSize(width: dw * 30, height: dw * 19)
        addChild(sprite)   
    }
    
}

